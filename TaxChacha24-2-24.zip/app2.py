import os
from flask import Flask, render_template, request, jsonify
import google.generativeai as genai

# Configure the Google Generative AI API
genai.configure(api_key=["AIzaSyAcHMRI-QXesOMsHuj2EZ9kJ3xHf88s4R8"])  # Get key from environment variables

# Set up the model configuration and safety settings
generation_config = {
    "temperature": 0.2,
    "top_p": 1,
    "top_k": 1,
    "max_output_tokens": 250,
}

safety_settings = [
    {
        "category": "HARM_CATEGORY_HARASSMENT",
        "threshold": "BLOCK_MEDIUM_AND_ABOVE"  # Stronger blocking
    },
    {
        "category": "HARM_CATEGORY_HATE_SPEECH",
        "threshold": "BLOCK_MEDIUM_AND_ABOVE"
    },
    {
        "category": "HARM_CATEGORY_SEXUALLY_EXPLICIT",
        "threshold": "BLOCK_MEDIUM_AND_ABOVE"
    },
    {
        "category": "HARM_CATEGORY_DANGEROUS_CONTENT",
        "threshold": "BLOCK_MEDIUM_AND_ABOVE"
    },
]

# Initialize the model with configuration
model = genai.GenerativeModel(model_name="gemini-1.0-pro",
                              generation_config=generation_config,
                              safety_settings=safety_settings)

app = Flask(__name__)

# Keep track of the conversation history
conversation_history = [] 

@app.route("/")
def index():
    return render_template('chat.html')

@app.route("/get", methods=["GET", "POST"])
def chat():
    msg = request.form["msg"]

    try:
        # If we don't need to start a new conversation, append and respond.
        if conversation_history:
            conversation_history.append({'role': 'user', 'parts': [msg]})
            response = model.send_message(conversation_history)

            # Trim excessive context to reduce redundant info in long chats
            if len(conversation_history) > 10:
                conversation_history = conversation_history[-8:] 

            return jsonify({"reply": response.text})

        # Start a new conversation if previous history is empty
        if is_corporate_tax_related(msg):
            conversation_history.clear()  # New topic reset history
            return start_conversation(msg)
        else:
            return jsonify({"reply": redirect_off_topic()})

    except Exception as e:
        # Generic error handling, log error for debugging
        print(f"Error occured: {e}") 
        return jsonify({"reply": "Oops, something went wrong. Could you try rephrasing your question?"})

def start_conversation(msg):
    # ... (Include the previous start_chat function code here) ...
    return jsonify({"reply": response.text})

def is_corporate_tax_related(query):
    """Checks if a query is relevant to UAE Corporate Tax"""
    # Use keywords, related terms, or a simple classifier here
    tax_keywords = ["corporate tax", "uae", "taxable income", "sbr", "deductions"]
    return any(word in query.lower() for word in tax_keywords)

def redirect_off_topic():
    return "I'm designed to help with UAE Corporate Tax matters. Can you please ask a question about that?"

if __name__ == '__main__':
    app.run()